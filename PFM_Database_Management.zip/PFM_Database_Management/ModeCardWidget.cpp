#include "ModeCardWidget.h"
#include <QDebug>

ModeCard::ModeCard(const QString &title, QWidget *parent)
    : QFrame(parent)
{
    setFrameShape(QFrame::StyledPanel);
    setFixedSize(300,250);
    setStyleSheet("background-color:black; border:2px solid white; color:white; border-radius:6px; padding:5px;");

    QVBoxLayout *layout = new QVBoxLayout(this);

    QLabel *titleLabel = new QLabel(title);
    titleLabel->setAlignment(Qt::AlignCenter);
    layout->addWidget(titleLabel);

    SymbolCard = new QWidget();
    SymbolCard->setStyleSheet("border:none;");
    QHBoxLayout *groupLayout = new QHBoxLayout(SymbolCard);
    groupBox = new QGroupBox();
    groupBox->setFixedSize(100, 100);
    groupBox->setStyleSheet("border : 2px solid white; background: transparent;");
    groupLayout->addStretch();
    groupLayout->addWidget(groupBox);
    groupLayout->addStretch();
    layout->addWidget(SymbolCard);

    QHBoxLayout *btnLayout = new QHBoxLayout();
    QPushButton *editBtn = new QPushButton("Edit");
    QPushButton *delBtn  = new QPushButton("Delete");
    editBtn->setStyleSheet("background-color:#00FFFF; color : black;");
    delBtn->setStyleSheet("background-color:#00FFFF; color : black;");

    btnLayout->addWidget(editBtn);
    btnLayout->addWidget(delBtn);
    layout->addLayout(btnLayout);

    connect(editBtn, &QPushButton::clicked, this, &ModeCard::editClicked);
    connect(delBtn, &QPushButton::clicked, this, &ModeCard::deleteClicked);

    // Setup animation timer
    connect(&animationTimer, &QTimer::timeout, this, [this]{
        animPos = (animPos + 5) % (2 * (width() + height()));

        angle += 2; // rotate clockwise
            if (angle >= 360) angle = 0;

        update();
    });

    animationTimer.start(50);
}

void ModeCard::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    int w = width();
    int h = height();

    // Border path
    p.setPen(QPen(Qt::gray, 7));
    p.drawRect(1, 1, w-2, h-2);

    // Animation light pen
    QPen lightPen(QColor("#00FFFF"), 7);
    p.setPen(lightPen);

    int len = 50;  // size of glowing segment
    int d = animPos;

    // Draw animated border segment
    if (d < w)                                  // top edge
        p.drawLine(d, 0, d + len, 0);
    else if (d < w + h)                         // right edge
        p.drawLine(w-1, d - w, w-1, d - w + len);
    else if (d < 2*w + h)                       // bottom edge
        p.drawLine((2*w + h) - d, h-1, (2*w + h) - d + len, h-1);
    else                                        // left edge
        p.drawLine(0, (2*w + 2*h) - d, 0, (2*w + 2*h) - d + len);


    int iCentreX =  SymbolCard->x() + (SymbolCard->width() /2);
    int iCentreY = SymbolCard->y() + (SymbolCard->height()/2);

    QPen DrawPen(QColor(0,255,0), 2);
    p.setPen(DrawPen);

    QFont Font("Arial");
    Font.setPointSize(20);
    p.setFont(Font);

    //p.drawText(iCentreX, iCentreY, "U");

    QRect squareRect(SymbolCard->x(), SymbolCard->y(), SymbolCard->width(), SymbolCard->height());

    QPoint top(squareRect.center().x(), squareRect.top());
    QPoint right(squareRect.right(), squareRect.center().y());
    QPoint bottom(squareRect.center().x(), squareRect.bottom());
    QPoint left(squareRect.left(), squareRect.center().y());

    QPolygon diamond;
    diamond << top << right << bottom << left;

   // p.drawLine(top, right);
    //p.drawLine(right, bottom);
    //p.drawLine(bottom, left);
    //p.drawLine(left, top);

    p.end();

}
