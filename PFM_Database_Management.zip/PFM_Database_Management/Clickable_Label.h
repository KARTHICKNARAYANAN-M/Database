#ifndef CLICKABLE_LABEL_H
#define CLICKABLE_LABEL_H

#include <QLabel>
#include <QWidget>
#include <QMouseEvent>

#if 0
class ClickableLabel : public QLabel
{
    Q_OBJECT
public:
    explicit ClickableLabel(const QString &text = "", QWidget *parent = nullptr)
        : QLabel(text, parent) {}

signals:
    void clicked();

protected:
    void mousePressEvent(QMouseEvent *event) override
    {
        emit clicked();
        QLabel::mousePressEvent(event);
    }
};
#endif // CLICKABLE_LABEL_H


#include <QLabel>
#include <QWidget>
#include <QMouseEvent>
#include <QEvent>

class ClickableLabel : public QLabel
{
    Q_OBJECT
public:
    explicit ClickableLabel(const QString &text = "", QWidget *parent = nullptr)
        : QLabel(text, parent)
    {
        setMouseTracking(true);
        setStyleSheet(normalStyle);
    }

signals:
    void clicked();

protected:
    void mousePressEvent(QMouseEvent *event) override
    {
        setStyleSheet(clickedStyle);
        emit clicked();
        QLabel::mousePressEvent(event);
    }

    void enterEvent(QEvent *event) override
    {
        if (!isClicked)
            setStyleSheet(hoverStyle);
        QLabel::enterEvent(event);
    }

    void leaveEvent(QEvent *event) override
    {
        if (!isClicked)
            setStyleSheet(normalStyle);
        QLabel::leaveEvent(event);
    }

private:
    bool isClicked = false;

    const QString normalStyle =
        "background-color:#21201E; color:green; font-size:20px; padding:4px; border-radius:3px;";

    const QString hoverStyle =
        "background-color:#2a241f; color:lightgreen; font-size:20px; padding:4px; border-radius:3px;";

    const QString clickedStyle =
        "background-color:#1E90FF; color:white; font-size:20px; padding:4px; border-radius:3px;";
};

#endif
