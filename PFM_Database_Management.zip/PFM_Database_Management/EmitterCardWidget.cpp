
#include "EmitterCardWidget.h"
#include "emitterdetailsdlg.h"

#include "Clickable_Label.h"

EmitterCard::EmitterCard(QWidget *parent)
    : QFrame(parent)
{
    setFrameShape(QFrame::StyledPanel);

    setStyleSheet("border : none");
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setContentsMargins(10,10,10,10);
    layout->setSpacing(10);

    // Add Emitter Button

    QWidget *EmitterWidget = new QWidget();
    QHBoxLayout *EmitterLayout = new QHBoxLayout(EmitterWidget);

    QWidget *LabelWidget =  new QWidget();
    LabelWidget->setFixedWidth(350);
    LabelWidget->setStyleSheet(
                "border : 2px solid white; background-color : #3498db; border-radius: 10px;");
    QVBoxLayout *LabelLayout =  new QVBoxLayout(LabelWidget);
    QLabel *Label = new QLabel("Add Emitter");
    Label->setAlignment(Qt::AlignCenter);
    Label->setStyleSheet(
                "border : none;"
                "color :  black;"
                "font-size: 20px;");
    LabelLayout->addWidget(Label, 0, Qt::AlignCenter);


    QWidget *AddButtonWidget =  new QWidget();
    AddButtonWidget->setStyleSheet(
                "border : 2px solid white; background-color : white; border-radius: 10px;");
    QVBoxLayout *AddButtonLayout =  new QVBoxLayout(AddButtonWidget);
    QPushButton *AddBtn = new QPushButton("+");
    AddBtn->setStyleSheet(
                "color : black;"
                "font-size : 20px;");
    AddButtonLayout->addWidget(AddBtn);

    EmitterLayout->addWidget(LabelWidget);
    EmitterLayout->addWidget(AddButtonWidget);

    layout->addWidget(EmitterWidget);

    emittersLayout = new QVBoxLayout();
    layout->addLayout(emittersLayout);

    connect(AddBtn, &QPushButton::clicked, this, &EmitterCard::addEmitterDialog);
}

EmitterCard::~EmitterCard()
{
   // delete ui;
}

void EmitterCard::addEmitterDialog()
{
   EmitterDetailsDlg *m_objEmitterDetailsDlg =  new EmitterDetailsDlg(this);



   if (m_objEmitterDetailsDlg->exec() == QDialog::Accepted)
          {
//              QString text = QString("%1 [%2]").arg(m_objdlgEmitterCard.emitterName(), m_objdlgEmitterCard.emitterType());
//              QLabel *label = new QLabel(text);
//              label->setStyleSheet(QString("background-color: %1; color: %2; padding:4px; border-radius:3px;")
//                                   .arg(m_objdlgEmitterCard.bgColor().name())
//                                   .arg(m_objdlgEmitterCard.fgColor().name()));

                QString Text = "[Emitter-1] Air Platform";
                ClickableLabel *label = new ClickableLabel(Text);
                label->setStyleSheet(
                            "background-color : #21201E;"
                            "color : green;"
                            "font-size : 20px;"
                            "padding:4px; "
                            "border-radius:3px;");

              emittersLayout->addWidget(label);

              // --- Connect the click to MainWindow ---
                     connect(label, &ClickableLabel::clicked, this, [this, Text]() {
                         emit emitterClicked(Text); // custom signal from EmitterCard
                     });
          }
}
