/********************************************************************************
** Form generated from reading UI file 'dp_rwr_app.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DP_RWR_APP_H
#define UI_DP_RWR_APP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dp_rwr_app
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *dp_rwr_app)
    {
        if (dp_rwr_app->objectName().isEmpty())
            dp_rwr_app->setObjectName(QString::fromUtf8("dp_rwr_app"));
        dp_rwr_app->resize(800, 600);
        centralwidget = new QWidget(dp_rwr_app);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        dp_rwr_app->setCentralWidget(centralwidget);
        menubar = new QMenuBar(dp_rwr_app);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        dp_rwr_app->setMenuBar(menubar);
        statusbar = new QStatusBar(dp_rwr_app);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        dp_rwr_app->setStatusBar(statusbar);

        retranslateUi(dp_rwr_app);

        QMetaObject::connectSlotsByName(dp_rwr_app);
    } // setupUi

    void retranslateUi(QMainWindow *dp_rwr_app)
    {
        dp_rwr_app->setWindowTitle(QCoreApplication::translate("dp_rwr_app", "dp_rwr_app", nullptr));
    } // retranslateUi

};

namespace Ui {
    class dp_rwr_app: public Ui_dp_rwr_app {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DP_RWR_APP_H
