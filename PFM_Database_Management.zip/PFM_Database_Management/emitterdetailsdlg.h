#ifndef EMITTERDETAILSDLG_H
#define EMITTERDETAILSDLG_H

#include <QDialog>
#include <QMainWindow>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPixmap>
#include <QGraphicsDropShadowEffect>
#include <QPropertyAnimation>
#include <QWidget>
#include <QGroupBox>
#include <QTimer>
#include <QPainter>
#include <QMouseEvent>
#include <QColorDialog>

namespace Ui {
class EmitterDetailsDlg;
}

class EmitterDetailsDlg : public QDialog
{
    Q_OBJECT

public:
    explicit EmitterDetailsDlg(QWidget *parent = nullptr);
    ~EmitterDetailsDlg();

    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);


protected:
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_obj_psh_btn_foreground_color_clicked();

    void on_obj_psh_btn_background_color_clicked();

    void on_obj_psh_btn_ok_clicked();

private:
    Ui::EmitterDetailsDlg *ui;
    QTimer animationTimer;
    int animPos = 0;
    qreal angle;

    QPoint dragPos;
};

#endif // EMITTERDETAILSDLG_H
