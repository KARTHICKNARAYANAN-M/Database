#ifndef DP_RWR_APP_H
#define DP_RWR_APP_H

#include <QMainWindow>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPixmap>
#include <QGraphicsDropShadowEffect>
#include <QPropertyAnimation>
#include <QWidget>
#include <QGroupBox>


#include "EmitterCardWidget.h"
#include "ModeCardWidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class dp_rwr_app; }
QT_END_NAMESPACE

class dp_rwr_app : public QMainWindow
{
    Q_OBJECT

public:
    dp_rwr_app(QWidget *parent = nullptr);
    ~dp_rwr_app();

    void DP_RWR_OnInitWidgets();

    QWidget *RightSideModePanel;
    QVBoxLayout *RightSideModeLayout;
    QPushButton *qModeBtn;

    QWidget *ModeWidget;
    QHBoxLayout *ModeHBoxLayout;


    void addModeCard();

public slots:
    void onEmitterClicked(const QString &emitterNam);

private:
    Ui::dp_rwr_app *ui;
};
#endif // DP_RWR_APP_H
