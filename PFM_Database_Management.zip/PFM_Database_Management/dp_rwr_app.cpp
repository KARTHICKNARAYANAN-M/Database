#include "dp_rwr_app.h"
#include "ui_dp_rwr_app.h"

#include <QDebug>
#include <QDialog>

dp_rwr_app::dp_rwr_app(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::dp_rwr_app)
{
    ui->setupUi(this);

    DP_RWR_OnInitWidgets();
}

dp_rwr_app::~dp_rwr_app()
{
    delete ui;
}

void dp_rwr_app::DP_RWR_OnInitWidgets()
{
    QWidget *central = new QWidget(this);
    setCentralWidget(central);
    // Apply full black background
    central->setStyleSheet("background-color: black;");

    // ----- Main Vertical Layout -----
    QVBoxLayout *mainLayout = new QVBoxLayout(central);
    mainLayout->setContentsMargins(10,10,10,10);
    mainLayout->setSpacing(8);

    // ---- Title Widget Creation -----/
    QWidget *TitleWidget =  new QWidget();
    TitleWidget->setFixedHeight(60);
    QHBoxLayout *TitleLayout =  new QHBoxLayout(TitleWidget);
    TitleLayout->setSpacing(25);

    // ----- Title ----- //
    QFont f("Helvetica");
    QLabel *title = new QLabel("PFM DATABASE MANAGEMENT");
    title->setFont(f);
    title->setAlignment(Qt::AlignCenter);
    title->setStyleSheet(
                "font-size: 28px;"
                "font-weight: bold;"
                "color: #00FFFF;"
                     // visible text on black background
                );


    // ----- Title Effect Glow ---- //
    QGraphicsDropShadowEffect *glow = new QGraphicsDropShadowEffect();
    glow->setColor(Qt::cyan);
    glow->setOffset(0, 0);
    glow->setBlurRadius(20);
    title->setGraphicsEffect(glow);

    QPropertyAnimation *glowAnim = new QPropertyAnimation(glow, "blurRadius");
    glowAnim->setDuration(2000);
    glowAnim->setStartValue(5);
    glowAnim->setEndValue(30);
    glowAnim->setLoopCount(-1);
    glowAnim->setEasingCurve(QEasingCurve::SineCurve);
    glowAnim->start();

    // ---------------------------- //

    // ----- Logo Start  ----- //
    QLabel *logo = new QLabel();
    QPixmap pix(":/Images/DP-Bright.bmp"); // replace with your path
    logo->setAlignment(Qt::AlignCenter);
    logo->setPixmap(pix);

    /*  Add Both Widgets */
    TitleLayout->addWidget(title);
    TitleLayout->addWidget(logo);

    // === Wrapper layout to center the whole header row ===
    QWidget *centerHolder = new QWidget();
    QHBoxLayout *centerLayout = new QHBoxLayout(centerHolder);
    centerLayout->addStretch();
    centerLayout->addWidget(TitleWidget);
    centerLayout->addStretch();

    //---- Main Container ----//
    QWidget *Container = new QWidget();
    Container->setMinimumHeight(800);
    Container->setStyleSheet(
                "border: 2px solid #595959; border-radius: 10px; ");
    QHBoxLayout *ContainerLayout = new QHBoxLayout(Container);
    ContainerLayout->setSpacing(15);    // optional: remove gaps
    ContainerLayout->setContentsMargins(10,10,10,10);

    QWidget *LeftSideEmitterModePanel =  new QWidget();
    LeftSideEmitterModePanel->setStyleSheet(
                "QWidget { border: 2px solid #3498db; border-radius: 10px; }");

    RightSideModePanel =  new QWidget();
    RightSideModePanel->setStyleSheet(
                "border: 4px solid #21201E; border-radius: 10px;");

    QVBoxLayout *EmitterLayout = new QVBoxLayout(LeftSideEmitterModePanel);

    // Add one card
    EmitterCard *card = new EmitterCard();
    EmitterLayout->addWidget(card);
    EmitterLayout->addStretch();

    connect(card, &EmitterCard::emitterClicked, this, &dp_rwr_app::onEmitterClicked);


    ContainerLayout->addWidget(LeftSideEmitterModePanel,  30);
    ContainerLayout->addWidget(RightSideModePanel, 70);



    mainLayout->addWidget(centerHolder);
    mainLayout->addWidget(Container);
    mainLayout->addStretch();


    central->setLayout(mainLayout);




#if 0
       // ----- Body Container -----
       QWidget *bodyContainer = new QWidget();
       bodyContainer->setStyleSheet("background-color: black;"); // keep black background
       QHBoxLayout *bodyLayout = new QHBoxLayout(bodyContainer);

       // Left side (30%)
       QWidget *leftPanel = new QWidget();
       leftPanel->setStyleSheet("background-color: #222222; border: 1px solid gray;");

       // Right side (70%)
       QWidget *rightPanel = new QWidget();
       rightPanel->setStyleSheet("background-color: #333333; border: 1px solid gray;");

       bodyLayout->addWidget(leftPanel, 3);
       bodyLayout->addWidget(rightPanel, 7);
#endif

       //mainLayout->addWidget(bodyContainer);


}

void dp_rwr_app::onEmitterClicked(const QString &emitterNam)
{
    // Right panel container

       RightSideModeLayout = new QVBoxLayout(RightSideModePanel);
       RightSideModeLayout->setContentsMargins(5,5,5,5);
       RightSideModeLayout->setSpacing(10);

       QWidget *ButtonWidget =  new QWidget();
       ButtonWidget->setStyleSheet("border : none");

       QHBoxLayout *ButtonLayout= new QHBoxLayout(ButtonWidget);
       // Initial Add Mode button
       qModeBtn = new QPushButton("+ Add Mode");
       qModeBtn->setStyleSheet("background-color: #21201E; color:white; padding:6px; border-radius:5px; font-size : 20px; height : 30px; width : 150px");
       ButtonLayout->addStretch();
       ButtonLayout->addWidget(qModeBtn);
       ButtonLayout->addStretch();

       connect(qModeBtn, &QPushButton::clicked, this, &dp_rwr_app::addModeCard);

       RightSideModeLayout->addWidget(ButtonWidget);


       ModeWidget = new QWidget();
       ModeWidget->setStyleSheet("border : none");
       ModeHBoxLayout =  new QHBoxLayout(ModeWidget);
       RightSideModeLayout->addWidget(ModeWidget);


       RightSideModeLayout->addStretch();


}


void dp_rwr_app::addModeCard()
{
    static int count = 1;
    QString title = QString("MID-%1").arg(count++);

    ModeCard *card = new ModeCard(title);


    // Insert card before the Add Mode button
    ModeHBoxLayout->insertWidget(ModeHBoxLayout->count() - 1, card);

    // Connect Edit
    connect(card, &ModeCard::editClicked, this, [=]() {
        QDialog dlg(this);
        dlg.setWindowTitle("Edit Mode");
        dlg.resize(300,150);
        dlg.exec();
    });

    // Connect Delete
    connect(card, &ModeCard::deleteClicked, this, [=]() {
        card->setParent(nullptr);
        card->deleteLater();
    });
}
