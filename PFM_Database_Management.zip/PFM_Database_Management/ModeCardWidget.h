#ifndef MODECARDWIDGET_H
#define MODECARDWIDGET_H

#include <QFrame>
#include <QVBoxLayout>
#include <QLabel>
#include <QGroupBox>
#include <QPushButton>
#include <QPainter>
#include <QTimer>

class ModeCard : public QFrame
{
    Q_OBJECT
public:
    explicit ModeCard(const QString &title, QWidget *parent = nullptr);

    QGroupBox *groupBox;
    QWidget *SymbolCard;

protected:
    void paintEvent(QPaintEvent *event) override;  // <--- override paint event

    bool m_bFlag = 0;

signals:
    void editClicked();
    void deleteClicked();

private:
    QTimer animationTimer;
    int animPos = 0;
    qreal angle;

    QPoint dragPos;
};

#endif
