#ifndef EMITTERCARDWIDGET_H
#define EMITTERCARDWIDGET_H

#include <QFrame>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>

class EmitterCard : public QFrame
{
    Q_OBJECT

public:
    EmitterCard(QWidget *parent = nullptr);
    ~EmitterCard();

signals:

    void emitterClicked(const QString &emitterName);

private slots:
    void addEmitterDialog();

private:
    QVBoxLayout *emittersLayout;
};
#endif // EMITTERCARDWIDGET_H
