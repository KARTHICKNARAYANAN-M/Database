#include "emitterdetailsdlg.h"
#include "ui_emitterdetailsdlg.h"

#include <QDebug>

EmitterDetailsDlg::EmitterDetailsDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EmitterDetailsDlg)
{
    ui->setupUi(this);

    setWindowFlags(windowFlags() | Qt::FramelessWindowHint);  // If you want custom border only
    setAttribute(Qt::WA_TranslucentBackground, true);

    // Setup animation timer
    connect(&animationTimer, &QTimer::timeout, this, [this]{
        animPos = (animPos + 5) % (2 * (width() + height()));

        angle += 2; // rotate clockwise
            if (angle >= 360) angle = 0;

        update();
    });

    setStyleSheet("color :  white; border-radius : none; ");

    ui->lineEdit->setStyleSheet(
                "color : white;"
                "border : 1px solid white;"
                "border-radius : none");


    ui->comboBox->setStyleSheet(
                "border : 1px solid white;"
                "border-radius : none");

    ui->obj_psh_btn_ok->setStyleSheet(
                "border : 2px solid white;"
                "color : black;"
                "border-radius : none;"
                "background-color : #00FFFF;");
    ui->obj_psh_btn_cancel->setStyleSheet(
                "border : 2px solid white;"
                "color : black;"
                "border-radius : none;"
                "background-color : #00FFFF;");
    ui->obj_psh_btn_foreground_color->setStyleSheet(
                "border : 2px solid white;"
                "border-radius : none");
    ui->obj_psh_btn_background_color->setStyleSheet(
                "border : 2px solid white;"
                "border-radius : none");

    ui->groupBox->setStyleSheet(
                "border : 2px solid white;"
                "border-radius : 0px;"
                "background: transparent"

                );

    ui->pushButton->setStyleSheet(
                "border : 2px solid white;"
                "border-radius : none;"
                "color :  black;"
                "background-color : #00FFFF;");

    animationTimer.start(30);

 }

EmitterDetailsDlg::~EmitterDetailsDlg()
{
    delete ui;
}

void EmitterDetailsDlg::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    int w = width();
    int h = height();

    // Border path
    p.setPen(QPen(Qt::gray, 7));
    p.drawRect(1, 1, w-2, h-2);

    // Animation light pen
    QPen lightPen(QColor("#00FFFF"), 7);
    p.setPen(lightPen);

    int len = 50;  // size of glowing segment
    int d = animPos;

    // Draw animated border segment
    if (d < w)                                  // top edge
        p.drawLine(d, 0, d + len, 0);
    else if (d < w + h)                         // right edge
        p.drawLine(w-1, d - w, w-1, d - w + len);
    else if (d < 2*w + h)                       // bottom edge
        p.drawLine((2*w + h) - d, h-1, (2*w + h) - d + len, h-1);
    else                                        // left edge
        p.drawLine(0, (2*w + 2*h) - d, 0, (2*w + 2*h) - d + len);


    int iCentreX =  ui->groupBox->x() + (ui->groupBox->width() /2);
    int iCentreY = ui->groupBox->y() + (ui->groupBox->height()/2);

    //iCentreX =  ui->groupBox->x();
    //iCentreY = ui->groupBox->y();

    int iCentreX1 = iCentreX - 15;
    int iCentreY1 = iCentreY + 10;


    QPen DrawPen(QColor(0,255,0), 2);
    p.setPen(DrawPen);

    QFont Font("Arial");
    Font.setPointSize(20);
    p.setFont(Font);

    p.drawText(iCentreX1, iCentreY1, "U");

    QRect squareRect(ui->groupBox->x(), ui->groupBox->y(), ui->groupBox->width(), ui->groupBox->height());

    QPoint top(squareRect.center().x(), squareRect.top());
    QPoint right(squareRect.right(), squareRect.center().y());
    QPoint bottom(squareRect.center().x(), squareRect.bottom());
    QPoint left(squareRect.left(), squareRect.center().y());

    QPolygon diamond;
    diamond << top << right << bottom << left;

    p.drawLine(top, right);
    p.drawLine(right, bottom);
    p.drawLine(bottom, left);
    p.drawLine(left, top);

    p.end();

}

void EmitterDetailsDlg::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
        dragPos = event->globalPos() - frameGeometry().topLeft();
}

void EmitterDetailsDlg::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
        move(event->globalPos() - dragPos);
}



void EmitterDetailsDlg::on_obj_psh_btn_foreground_color_clicked()
{
    QColor color = QColorDialog::getColor(Qt::white, this, "Select a Color");
}

void EmitterDetailsDlg::on_obj_psh_btn_background_color_clicked()
{
    QColor color = QColorDialog::getColor(Qt::white, this, "Select a Color");
}

void EmitterDetailsDlg::on_obj_psh_btn_ok_clicked()
{
    QDialog::accept();
}
