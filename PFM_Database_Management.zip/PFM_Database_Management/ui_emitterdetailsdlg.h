/********************************************************************************
** Form generated from reading UI file 'emitterdetailsdlg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMITTERDETAILSDLG_H
#define UI_EMITTERDETAILSDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_EmitterDetailsDlg
{
public:
    QGridLayout *gridLayout_6;
    QGridLayout *gridLayout_5;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton;
    QGridLayout *gridLayout_4;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QComboBox *comboBox;
    QLabel *label_3;
    QPushButton *obj_psh_btn_foreground_color;
    QLabel *label_4;
    QPushButton *obj_psh_btn_background_color;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *obj_psh_btn_ok;
    QPushButton *obj_psh_btn_cancel;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QDialog *EmitterDetailsDlg)
    {
        if (EmitterDetailsDlg->objectName().isEmpty())
            EmitterDetailsDlg->setObjectName(QString::fromUtf8("EmitterDetailsDlg"));
        EmitterDetailsDlg->resize(399, 275);
        gridLayout_6 = new QGridLayout(EmitterDetailsDlg);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_3, 0, 0, 1, 1);

        pushButton = new QPushButton(EmitterDetailsDlg);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(30, 30));

        gridLayout_5->addWidget(pushButton, 0, 1, 1, 1);


        gridLayout_6->addLayout(gridLayout_5, 0, 0, 1, 1);

        gridLayout_4 = new QGridLayout();
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setVerticalSpacing(15);
        groupBox = new QGroupBox(EmitterDetailsDlg);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(150, 150));

        gridLayout_4->addWidget(groupBox, 0, 0, 1, 1);

        groupBox_2 = new QGroupBox(EmitterDetailsDlg);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit = new QLineEdit(groupBox_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        comboBox = new QComboBox(groupBox_2);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        gridLayout->addWidget(comboBox, 1, 1, 1, 1);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        obj_psh_btn_foreground_color = new QPushButton(groupBox_2);
        obj_psh_btn_foreground_color->setObjectName(QString::fromUtf8("obj_psh_btn_foreground_color"));

        gridLayout->addWidget(obj_psh_btn_foreground_color, 2, 1, 1, 1);

        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        obj_psh_btn_background_color = new QPushButton(groupBox_2);
        obj_psh_btn_background_color->setObjectName(QString::fromUtf8("obj_psh_btn_background_color"));

        gridLayout->addWidget(obj_psh_btn_background_color, 3, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        gridLayout_4->addWidget(groupBox_2, 0, 1, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setHorizontalSpacing(15);
        gridLayout_3->setVerticalSpacing(6);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 0, 0, 1, 1);

        obj_psh_btn_ok = new QPushButton(EmitterDetailsDlg);
        obj_psh_btn_ok->setObjectName(QString::fromUtf8("obj_psh_btn_ok"));
        obj_psh_btn_ok->setMinimumSize(QSize(45, 30));

        gridLayout_3->addWidget(obj_psh_btn_ok, 0, 1, 1, 1);

        obj_psh_btn_cancel = new QPushButton(EmitterDetailsDlg);
        obj_psh_btn_cancel->setObjectName(QString::fromUtf8("obj_psh_btn_cancel"));
        obj_psh_btn_cancel->setMinimumSize(QSize(45, 30));

        gridLayout_3->addWidget(obj_psh_btn_cancel, 0, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_2, 0, 3, 1, 1);


        gridLayout_4->addLayout(gridLayout_3, 1, 0, 1, 2);


        gridLayout_6->addLayout(gridLayout_4, 1, 0, 1, 1);


        retranslateUi(EmitterDetailsDlg);

        QMetaObject::connectSlotsByName(EmitterDetailsDlg);
    } // setupUi

    void retranslateUi(QDialog *EmitterDetailsDlg)
    {
        EmitterDetailsDlg->setWindowTitle(QCoreApplication::translate("EmitterDetailsDlg", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("EmitterDetailsDlg", "x", nullptr));
        groupBox->setTitle(QString());
        groupBox_2->setTitle(QString());
        label->setText(QCoreApplication::translate("EmitterDetailsDlg", "Emitter Name :", nullptr));
        label_2->setText(QCoreApplication::translate("EmitterDetailsDlg", "Emitter Type", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("EmitterDetailsDlg", "Air", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("EmitterDetailsDlg", "Ground", nullptr));

        label_3->setText(QCoreApplication::translate("EmitterDetailsDlg", "Emitter Foreground\n"
"Color", nullptr));
        obj_psh_btn_foreground_color->setText(QCoreApplication::translate("EmitterDetailsDlg", "Choose", nullptr));
        label_4->setText(QCoreApplication::translate("EmitterDetailsDlg", "Emitter Background\n"
"Color", nullptr));
        obj_psh_btn_background_color->setText(QCoreApplication::translate("EmitterDetailsDlg", "Choose", nullptr));
        obj_psh_btn_ok->setText(QCoreApplication::translate("EmitterDetailsDlg", "Ok", nullptr));
        obj_psh_btn_cancel->setText(QCoreApplication::translate("EmitterDetailsDlg", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EmitterDetailsDlg: public Ui_EmitterDetailsDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMITTERDETAILSDLG_H
